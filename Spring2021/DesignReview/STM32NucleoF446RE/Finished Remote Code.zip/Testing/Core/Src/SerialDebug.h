#ifndef SRC_SERIALDEBUG_H_
#define SRC_SERIALDEBUG_H_

#include <stdio.h>
#include <string.h>

#include "main.h"

// Function Definitions
void DebugBegin();
void DebugLog(char * message);

#endif /* SRC_SERIALDEBUG_H_ */
