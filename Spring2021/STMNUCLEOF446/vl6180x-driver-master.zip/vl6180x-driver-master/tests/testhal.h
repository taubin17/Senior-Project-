#ifndef TESTHAL_H
#define TESTHAL_H
#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int dummy; /* C++ has different conventions for empty structures. */
} I2CDriver;

#ifdef __cplusplus
}
#endif
#endif
